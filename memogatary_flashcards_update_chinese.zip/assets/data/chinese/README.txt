
# Flashcard App Data Placement (Chinese)

Put your HSK vocab Excel file here:
```
assets/data/chinese/HSK20VocabularyApp.xlsx
```

Then the Flashcard App page will fetch it using a relative path:
```
/assets/data/chinese/HSK20VocabularyApp.xlsx
```
This keeps all raw data in `assets/data/` but organized by language.
